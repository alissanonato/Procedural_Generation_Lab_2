#pragma once
namespace sf { class Image; }
void mpDisplacement(double roughness, sf::Image &img, bool isBound);