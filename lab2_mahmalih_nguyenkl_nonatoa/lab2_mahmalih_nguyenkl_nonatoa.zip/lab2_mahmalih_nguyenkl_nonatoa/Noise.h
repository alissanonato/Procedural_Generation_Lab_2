#pragma once
#include <string>
namespace sf { class Image; }

void noise(sf::Image &img, std::string &mode);