#pragma once
namespace sf { class Image; }
void diceRoll(sf::Image &img, int numRolls, int numSides);

